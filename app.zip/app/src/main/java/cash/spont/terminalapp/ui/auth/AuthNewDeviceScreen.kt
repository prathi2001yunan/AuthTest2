package cash.spont.terminalapp.ui.component

import android.content.res.Configuration
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.dp

@Composable
fun AuthNewDeviceScreen(onNext: (name: String) -> Unit, onBack: () -> Unit) {
    val configuration = LocalConfiguration.current
    when (configuration.orientation) {
        Configuration.ORIENTATION_LANDSCAPE -> {
            AuthNewDeviceScreenLandscape(
                onNext = {name ->
                    onNext(name)
                },
                onBack = {
                    onBack()
                }
            )
        }

        else -> {
            AuthNewDeviceScreenPortrait(
                onNext = {name ->
                    onNext(name)
                },
                onBack = {
                    onBack()
                }
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuthNewDeviceScreenPortrait(onNext: (name: String) -> Unit, onBack: () -> Unit) {
    var value by remember { mutableStateOf("") }
    Scaffold(
        topBar = {
            AuthNewDeviceScreenTopbar(onClick = { onBack() })
        },
        bottomBar = {
            BottomAppBar(
                containerColor = MaterialTheme.colorScheme.background
            ) {
                Button(
                    onClick = { onNext(value) },
                    shape = MaterialTheme.shapes.small,
                    modifier = Modifier.fillMaxWidth()
                        .height(55.dp)
                        .padding(horizontal = 15.dp),
                    colors = ButtonDefaults.buttonColors(MaterialTheme.colorScheme.primary),
                    enabled = value.isNotEmpty()
                ) {
                    Text(
                        "Next",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (value.isNotEmpty()) Color.White else Color.LightGray
                    )
                }
            }
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        Column(
            modifier = Modifier.fillMaxWidth()
                .padding(paddingValues = paddingValues)
                .padding(top = 25.dp)
        ) {
            Text(
                text = "NAME",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.padding(start = 12.dp)
            )
            TextField(
                value = value,
                onValueChange = { value = it },
                modifier = Modifier.fillMaxWidth()
                    .height(80.dp)
                    .padding(12.dp)
                    .clip(MaterialTheme.shapes.small)
                    .border(1.dp, Color.Transparent, MaterialTheme.shapes.small),
                colors = TextFieldDefaults.textFieldColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    disabledIndicatorColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent
                ),
                singleLine = true
            )
        }
    }
}

@Composable
fun AuthNewDeviceScreenTopbar(onClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth()
            .padding(horizontal = 15.dp)
            .padding(top = 20.dp, bottom = 20.dp),
    ) {
        Card(
            shape = MaterialTheme.shapes.extraLarge,
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer
            ),
            modifier = Modifier.clip(MaterialTheme.shapes.extraLarge)
                .clickable { onClick() }
        ) {
            Icon(
                imageVector = Icons.Default.KeyboardArrowLeft,
                contentDescription = null,
                modifier = Modifier.size(50.dp, 50.dp)
                    .padding(10.dp),
                tint = MaterialTheme.colorScheme.onPrimary
            )
        }
        Spacer(modifier = Modifier.width(20.dp))
        Row(
        ) {
            Text(
                text = "Configure",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuthNewDeviceScreenLandscape(onNext: (name: String) -> Unit, onBack: () -> Unit) {
    var value by remember { mutableStateOf("") }
    Scaffold(
        topBar = {
            AuthNewDeviceScreenTopbarLandscape(onClick = { onBack() })
        },
        bottomBar = {
            BottomAppBar(
                containerColor = MaterialTheme.colorScheme.background
            ) {
                Button(
                    onClick = { onNext(value) },
                    shape = MaterialTheme.shapes.small,
                    modifier = Modifier.fillMaxWidth()
                        .height(55.dp)
                        .padding(horizontal = 15.dp),
                    colors = ButtonDefaults.buttonColors(MaterialTheme.colorScheme.primary),
                    enabled = value.isNotEmpty()
                ) {
                    Text(
                        "Next",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (value.isNotEmpty()) Color.White else Color.LightGray
                    )
                }
            }
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        Column(
            modifier = Modifier.fillMaxWidth()
                .padding(paddingValues = paddingValues)
                .padding(top = 25.dp)
        ) {
            Text(
                text = "NAME",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.padding(start = 12.dp)
            )
            TextField(
                value = value,
                onValueChange = { value = it },
                modifier = Modifier.fillMaxWidth()
                    .height(70.dp)
                    .padding(12.dp)
                    .clip(MaterialTheme.shapes.small)
                    .border(1.dp, Color.Transparent, MaterialTheme.shapes.small),
                colors = TextFieldDefaults.textFieldColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    disabledIndicatorColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent
                ),
                singleLine = true
            )
        }
    }
}

@Composable
fun AuthNewDeviceScreenTopbarLandscape(onClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth()
            .padding(horizontal = 15.dp)
            .padding(top = 20.dp, bottom = 20.dp),
    ) {
        Card(
            shape = MaterialTheme.shapes.extraLarge,
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer
            ),
            modifier = Modifier.clip(MaterialTheme.shapes.extraLarge)
                .clickable { onClick() }
        ) {
            Icon(
                imageVector = Icons.Default.KeyboardArrowLeft,
                contentDescription = null,
                modifier = Modifier.size(50.dp, 50.dp)
                    .padding(8.dp),
                tint = MaterialTheme.colorScheme.onPrimary
            )
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Configure",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.padding(top = 15.dp)
            )
        }
    }
}