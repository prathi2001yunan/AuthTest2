package cash.spont.terminalapp.model

import java.text.NumberFormat
import java.util.Locale

data class Tip (
    val percentage: Int,
    val amount: Double
)

fun moneyFormat(amount: Double): String {
    val moneyFormat = NumberFormat.getCurrencyInstance(Locale.ITALY)
    val amountValue = moneyFormat.format(amount).toString()
    return moneyFormat.currency?.symbol + amountValue.subSequence(0, amountValue.length - 1)
}