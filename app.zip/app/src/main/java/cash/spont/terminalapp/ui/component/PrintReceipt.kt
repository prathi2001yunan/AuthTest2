package cash.spont.terminalapp.ui.component

import android.content.res.Configuration
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import cash.spont.terminalapp.ui.qr.QRCode
import cash.spont.terminalapp.ui.qr.QrCodeProperties

@Composable
fun PrintReceipt() {
    val configuration = LocalConfiguration.current
    when (configuration.orientation) {
        Configuration.ORIENTATION_LANDSCAPE -> {
            PrintReceiptLandscape()
        }

        else -> {
            PrintReceiptPortrait()
        }
    }
}

@Composable
fun PrintReceiptLandscape() {
    Box(
        Modifier
            .width(180.dp)
            .fillMaxHeight()
            .padding(vertical = 10.dp, horizontal = 10.dp)
            .clip(MaterialTheme.shapes.small)
            .background(MaterialTheme.colorScheme.primaryContainer, MaterialTheme.shapes.small)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(),
            Arrangement.Center,
            Alignment.CenterHorizontally
        ) {
            PrintReceiptQRCode(modifier = Modifier.size(100.dp))
            Spacer(modifier = Modifier.size(15.dp))
            PrintScanText(
                true,
                Modifier
                    .fillMaxWidth()
                    .padding(10.dp)
            )
            Spacer(modifier = Modifier.size(15.dp))
            Divider(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
            )
            Spacer(modifier = Modifier.size(15.dp))
            PrintReceiptButton(
                modifier = Modifier
                    .height(50.dp)
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp), 10,
                onClick = { }
            )
        }
    }
}

@Composable
fun PrintReceiptPortrait() {
    Box(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 20.dp)
            .clip(MaterialTheme.shapes.small)
            .background(MaterialTheme.colorScheme.primaryContainer, MaterialTheme.shapes.small)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 10.dp)
                .padding(bottom = 10.dp),
            Arrangement.Center,
            Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 30.dp),
                Arrangement.SpaceBetween,
                Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.fillMaxWidth(0.6f)) {
                    PrintScanText(modifier = Modifier)
                }
                PrintReceiptQRCode(modifier = Modifier.size(100.dp))
            }
            Spacer(modifier = Modifier.size(10.dp))
            PrintReceiptButton(
                modifier = Modifier
                    .height(65.dp)
                    .fillMaxWidth()
                    .padding(horizontal = 15.dp), 17,
                onClick = {

                }
            )
        }
    }
}

@Composable
private fun PrintReceiptQRCode(modifier: Modifier) {
    QRCode(
        contents = "www.gmail.com",
        modifier = modifier
            .size(120.dp),
        qrCodeProperties = QrCodeProperties(
            foreground = MaterialTheme.colorScheme.onPrimary,
            background = Color.Transparent
        )
    )
}

@Composable
private fun PrintScanText(landScape: Boolean = false, modifier: Modifier) {
    Text(
        text = "Scan for Receipt",
        fontWeight = FontWeight.Bold,
        fontSize = 16.sp,
        color = MaterialTheme.colorScheme.onPrimary,
    )
    Spacer(modifier = Modifier.size(10.dp))
    Text(
        text = "Scan QR Code to receive receipt per mail.",
        textAlign = if (landScape) TextAlign.Center else TextAlign.Start,
        fontWeight = FontWeight.W500,
        lineHeight = 15.sp,
        color = MaterialTheme.colorScheme.secondary,
        fontSize = 14.sp,
        modifier = modifier
    )
}

@Composable
private fun PrintReceiptButton(modifier: Modifier, fontSize: Int, onClick: () -> Unit) {
    androidx.compose.material3.Button(
        onClick = { onClick() },
        modifier = modifier,
        shape = RoundedCornerShape(15.dp),
        colors = ButtonDefaults.buttonColors(MaterialTheme.colorScheme.onSecondary)
    ) {
        Text(
            text = "Print receipt",
            fontSize = fontSize.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
    }
}