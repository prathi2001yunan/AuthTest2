package cash.spont.terminalapp.ui.component


import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import cash.spont.terminalapp.model.AuthOption

@Composable
fun AuthCompanyScreen(onSelect: (companyId: String) -> Unit) {
    val authOptions = listOf(
        AuthOption("1", "Amsterdam West"),
        AuthOption("2", "Amsterdam Zvid"),
        AuthOption("3", "Jan Pieter Straat"),
    )
    Scaffold(
        topBar = { AuthCompanyScreenTopbar() },
        bottomBar = {
            BottomAppBar(
                containerColor = MaterialTheme.colorScheme.background
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Logo()
                }
            }
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier.fillMaxWidth()
                .padding(horizontal = 15.dp)
                .padding(paddingValues = paddingValues)
        ) {
            items(count = authOptions.size) { index ->
                val shape =
                    if (index == 0)
                        MaterialTheme.shapes.medium
                    else if (index == authOptions.size - 1)
                        MaterialTheme.shapes.large
                    else
                        MaterialTheme.shapes.small
                OptionList(
                    authOption = authOptions.get(index),
                    shape = shape,
                    onClick = {
                       onSelect(authOptions.get(index).id)
                    }
                )
            }
            item {
                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }
}

@Composable
fun AuthCompanyScreenTopbar() {
    Row(
        modifier = Modifier.fillMaxWidth()
            .padding(horizontal = 15.dp)
            .padding(top = 20.dp, bottom = 10.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
        ) {
            Text(
                text = "Select company",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
    }
}