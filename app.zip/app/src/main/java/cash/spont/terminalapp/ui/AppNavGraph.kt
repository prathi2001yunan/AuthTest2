package cash.spont.terminalapp.ui

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import cash.spont.terminalapp.ui.auth.AuthScreen
import cash.spont.terminalapp.ui.order.OrderScreen

@Composable
fun AppNavGraph() {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = NavRoute.Auth.route) {
        composable(NavRoute.Auth.route) {
               AuthScreen(navController)
        }
	   composable(NavRoute.Order.route) {
            OrderScreen(navController)
        }
    }
}
