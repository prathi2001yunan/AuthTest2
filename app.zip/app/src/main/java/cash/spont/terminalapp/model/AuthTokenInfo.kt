package cash.spont.terminalapp.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class AuthTokenInfo(
    @SerialName("error")  var error: String = "",
    @SerialName("error_message") var message: String = "",
    @SerialName("access_token") var accessToken: String = "",
    @SerialName("refresh_token") var refreshToken: String = "",
    @SerialName("scope") var scope: String = "",
    @SerialName("expires_in") var expiresIn: Int = 0,
    @SerialName("token_type") var tokenType: String = ""
   )
