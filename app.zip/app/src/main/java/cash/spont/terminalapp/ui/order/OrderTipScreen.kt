package cash.spont.terminalapp.ui.component

import android.content.res.Configuration
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import cash.spont.terminalapp.model.Tip
import cash.spont.terminalapp.ui.common.formatPrice

@Composable
fun OrderTipScreen() {
    val configuration = LocalConfiguration.current
    when (configuration.orientation) {
        Configuration.ORIENTATION_LANDSCAPE -> {
            OrderTipScreenLandScape()
        }

        else -> {
            OrderTipScreenPortrait()
        }
    }
}

@Composable
fun OrderTipScreenPortrait() {
    var selectedTip: MutableState<Double> = remember {
        mutableStateOf(0.0)
    }

    var useTip = remember {
        mutableStateOf(false)
    }

    var customAmount = remember {
        mutableStateOf(false)
    }

    var showBottomSheet = remember {
        mutableStateOf(false)
    }

    Scaffold(
        topBar = {
            TopBar("ORDER TOTAL", 27.40)
        },
        bottomBar = {
            BottomBar(
                isClick = useTip.value,
                isSelectedTip = selectedTip.value != 0.0,
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
    ) { paddingVales ->
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(paddingValues = paddingVales),
        ) {
            Spacer(modifier = Modifier.height(8.dp))
            TipsItems(
                tips = listOf(
                    Tip(10, 2.70),
                    Tip(15, 5.40),
                    Tip(20, 8.10),
                ),
                selectedTip = selectedTip,
                onClick = {
                    selectedTip.value = it
                    customAmount.value = false
                },
                onShow = {
                    showBottomSheet.value = true
                },
                isCustom = customAmount.value,
            )
        }
    }
    if (showBottomSheet.value) {
        CustomTipScreen(
            onClose = {
                showBottomSheet.value = false
            },
            onSave = {
                useTip.value = true
                customAmount.value = true
                selectedTip.value = 0.0
            },
        )
    }
}

@Composable
fun TopBar(name: String, amount: Double) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 25.dp),
    ) {
        Spacer(Modifier.height(42.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
            Text(
                text = "Add tip?",
                color = MaterialTheme.colorScheme.onPrimary,
                style = MaterialTheme.typography.headlineLarge,
                textAlign = TextAlign.Center,
            )
        }
        Spacer(modifier = Modifier.height(23.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.primary, MaterialTheme.shapes.medium)
                .height(53.dp)
                .padding(horizontal = 25.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = name,
                color = Color.White,
                style = MaterialTheme.typography.headlineSmall,
            )
            Spacer(modifier = Modifier.width(84.dp))
            Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.End) {
                Text(
                    text = formatPrice(amount),
                    color = Color.White,
                    style = MaterialTheme.typography.headlineMedium,
                )
            }
        }
    }
}

@Composable
fun TipsItems(
    tips: List<Tip>,
    selectedTip: MutableState<Double>,
    isCustom: Boolean,
    onClick: (Double) -> Unit,
    onShow: () -> Unit,
) {
    LazyColumn {
        items(count = tips.size) { countValue ->
            TipItemView(
                tip = tips[countValue],
                isClick = selectedTip.value == (tips[countValue].amount),
                onClick = { tipAmount ->
                    if (tipAmount == tips[countValue].amount) {
                        onClick(tipAmount)
                    }
                },
            )
        }
        item {
            CustomAmount(
                isClick = isCustom,
                onClick = {
                    onShow()
                },
            )
        }
    }
}

@Composable
fun TipItemView(tip: Tip, isClick: Boolean, onClick: (Double) -> Unit) {
    var selectedTipColor = MaterialTheme.colorScheme.primaryContainer
    var textColor = MaterialTheme.colorScheme.onPrimary
    if (isClick) {
        selectedTipColor = MaterialTheme.colorScheme.primary
        textColor = Color.White
    }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 25.dp)
            .background(
                selectedTipColor,
                MaterialTheme.shapes.small,
            )
            .clip(MaterialTheme.shapes.small)
            .height(75.dp)
            .clickable {
                onClick(tip.amount)
            },
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 25.dp)
                .fillMaxHeight(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                "${tip.percentage}%",
                color = textColor,
                fontSize = 20.sp,
                fontWeight = FontWeight.ExtraBold,
            )
            Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.End) {
                Text(
                    "+ ${formatPrice(tip.amount)}",
                    color = textColor,
                    fontSize = 19.sp,
                    fontWeight = FontWeight.SemiBold,
                )
            }
        }
    }
    Spacer(modifier = Modifier.height(7.dp))
}

@Composable
fun CustomAmount(isClick: Boolean, onClick: () -> Unit) {
    var color = MaterialTheme.colorScheme.primaryContainer
    var textColor = MaterialTheme.colorScheme.onPrimary
    if (isClick) {
        color = MaterialTheme.colorScheme.primary
        textColor = Color.White
    }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 25.dp)
            .background(color, MaterialTheme.shapes.large)
            .height(75.dp)
            .clickable { onClick() }
            .fillMaxHeight(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            "Custom amount",
            color = textColor,
            style = MaterialTheme.typography.displaySmall,
        )
    }
    Spacer(Modifier.height(30.dp))
}

@Composable
fun BottomBar(isClick: Boolean, isSelectedTip: Boolean) {
    var text = "No thanks"
    var color = MaterialTheme.colorScheme.primaryContainer
    if (isClick || isSelectedTip) {
        text = "Use tip amount"
        color = MaterialTheme.colorScheme.primary
    }
    Column() {
        Button(
            onClick = { /*TODO*/ },
            colors = ButtonDefaults.buttonColors(color),
            shape = MaterialTheme.shapes.extraLarge,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 25.dp)
                .padding(bottom = 20.dp)
                .height(67.dp),
        ) {
            Text(
                text,
                color = Color.White,
                style = MaterialTheme.typography.bodyMedium,
            )
        }
    }
}

@Composable
fun OrderTipScreenLandScape() {
    var selectedTip: MutableState<Double> = remember {
        mutableStateOf(0.0)
    }

    var showBottomSheet = remember {
        mutableStateOf(false)
    }

    var useTip = remember {
        mutableStateOf(false)
    }

    var customAmount = remember {
        mutableStateOf(false)
    }

    Scaffold(
        topBar = {
            TopBarLandScape("ORDER TOTAL", 27.40)
        },
        bottomBar = {
            BottomBar(isClick = useTip.value, isSelectedTip = selectedTip.value != 0.0)
        },
        containerColor = MaterialTheme.colorScheme.background,
    ) { paddingVales ->
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(paddingValues = paddingVales),
        ) {
            Spacer(modifier = Modifier.height(10.dp))
            TipsItemsLandscape(
                tips = listOf(
                    Tip(10, 2.74),
                    Tip(15, 3.80),
                    Tip(20, 5.10),
                    Tip(20, 6.10),
                ),
                selectedTip = selectedTip,
                isCustom = customAmount.value,
                onClick = {
                    selectedTip.value = it
                    customAmount.value = false
                },
                onShow = {
                    showBottomSheet.value = true
                },
            )
        }
    }
    if (showBottomSheet.value) {
        CustomTipScreen(
            onClose = {
                showBottomSheet.value = false
            },
            onSave = {
                useTip.value = true
                customAmount.value = true
                selectedTip.value = 0.0
            },
        )
    }
}

@Composable
fun TopBarLandScape(name: String, amount: Double) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 25.dp),
    ) {
        Spacer(Modifier.height(26.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
            Text(
                text = "Add tip?",
                color = MaterialTheme.colorScheme.onPrimary,
                style = MaterialTheme.typography.headlineLarge,
                textAlign = TextAlign.Center,
            )
        }
        Spacer(modifier = Modifier.height(18.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.primary, MaterialTheme.shapes.medium)
                .height(48.dp)
                .padding(horizontal = 25.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = name,
                color = Color.White,
                style = MaterialTheme.typography.displaySmall,
            )
            Spacer(modifier = Modifier.width(84.dp))
            Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.End) {
                Text(
                    text = formatPrice(amount),
                    color = Color.White,
                    style = MaterialTheme.typography.headlineMedium,
                )
            }
        }
    }
}

@Composable
fun TipsItemsLandscape(
    tips: List<Tip>,
    selectedTip: MutableState<Double>,
    isCustom: Boolean,
    onClick: (Double) -> Unit,
    onShow: () -> Unit,
) {
    LazyRow(modifier = Modifier.padding(horizontal = 25.dp)) {
        item {
        }
        items(count = tips.size) { countValue ->
            TipItemViewLandscape(
                tip = tips[countValue],
                count = countValue,
                isClick = selectedTip.value == (tips[countValue].amount),
                onClick = { tipAmount ->
                    if (tipAmount == tips[countValue].amount) {
                        onClick(tipAmount)
                    }
                },
            )
        }
        item {
            CustomAmountLandScape(
                isClick = isCustom,
                onClick = {
                    onShow()
                },
            )
        }
    }
}

@Composable
fun TipItemViewLandscape(tip: Tip, count: Int, isClick: Boolean, onClick: (Double) -> Unit) {
    var shape = MaterialTheme.shapes.small
    if (count == 0) {
        shape = MaterialTheme.shapes.extraSmall
    }
    var selectedTipColor = MaterialTheme.colorScheme.primaryContainer
    var textColor = MaterialTheme.colorScheme.onPrimary
    if (isClick) {
        selectedTipColor = MaterialTheme.colorScheme.primary
        textColor = Color.White
    }
    Column(
        modifier = Modifier
            .background(
                selectedTipColor,
                shape,
            )
            .clickable { onClick(tip.amount) }
            .size(180.dp, 120.dp),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 25.dp)
                .fillMaxHeight(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Text(
                "${tip.percentage}%",
                color = textColor,
                style = MaterialTheme.typography.headlineLarge,
            )
            Spacer(modifier = Modifier.height(5.dp))
            Text(
                "+ ${formatPrice(tip.amount)}",
                color = textColor,
                style = MaterialTheme.typography.bodyMedium,
            )
        }
    }
    Spacer(modifier = Modifier.width(11.dp))
}

@Composable
fun CustomAmountLandScape(isClick: Boolean, onClick: () -> Unit) {
    var color = MaterialTheme.colorScheme.primaryContainer
    var textColor = MaterialTheme.colorScheme.onPrimary
    if (isClick) {
        color = MaterialTheme.colorScheme.primary
        textColor = Color.White
    }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                color,
                RoundedCornerShape(10.dp, 10.dp, 30.dp, 10.dp),
            )
            .size(180.dp, 120.dp)
            .fillMaxHeight()
            .clickable { onClick() },
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(modifier = Modifier.height(15.dp))
        Icon(imageVector = Icons.Default.Edit, contentDescription = null)
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            "Custom",
            color = textColor,
            style = MaterialTheme.typography.headlineMedium,
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomTipScreen(onClose: () -> Unit, onSave: () -> Unit) {
    val sheetState = rememberModalBottomSheetState()

    var value by remember {
        mutableStateOf("")
    }
    ModalBottomSheet(
        onDismissRequest = { onClose() },
        sheetState = sheetState,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 25.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            TextField(
                value = value,
                onValueChange = { value = it },
                placeholder = {
                    Text("Enter tip amount")
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(80.dp)
                    .padding(12.dp)
                    .clip(MaterialTheme.shapes.small)
                    .border(1.dp, Color.Transparent, MaterialTheme.shapes.small),
                colors = TextFieldDefaults.textFieldColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    disabledIndicatorColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    cursorColor = Color.White,
                ),
                singleLine = true,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Number,
                    imeAction = ImeAction.Search,
                ),
            )
            Spacer(modifier = Modifier.height(15.dp))
            Button(
                onClick = {
                    onSave()
                    onClose()
                },
                shape = MaterialTheme.shapes.extraLarge,
                modifier = Modifier
                    .size(110.dp, 40.dp),
            ) {
                Text(
                    "Save",
                    color = Color.White,
                    style = MaterialTheme.typography.headlineSmall,
                )
            }
            Spacer(modifier = Modifier.height(60.dp))
        }
    }
}
