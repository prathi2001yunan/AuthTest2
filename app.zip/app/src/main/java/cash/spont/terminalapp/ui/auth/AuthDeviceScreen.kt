package cash.spont.terminalapp.ui.component

import android.content.res.Configuration
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import cash.spont.terminalapp.R
import cash.spont.terminalapp.model.AuthOption

@Composable
fun AuthDeviceScreen(onAdd: () -> Unit, onSelect: (deviceId: String) -> Unit, onBack: () -> Unit) {
    val authOptions = listOf(
        AuthOption("1", "Kasssar Bar I"),
        AuthOption("2", "Achtern Kassa"),
        AuthOption("3", "Kasssa Bar II"),
        AuthOption("4", "Kassa Voorin V"),
        AuthOption("5", "Terras Bestel ziul"),
    )
    val configuration = LocalConfiguration.current
    when (configuration.orientation) {
        Configuration.ORIENTATION_LANDSCAPE -> {
            AuthDeviceScreenLandscape(
                authOptions = authOptions,
                onAdd = {
                    onAdd()
                },
                onSelect = { deviceId ->
                    onSelect(deviceId)
                },
                onBack = {
                    onBack()
                }
            )
        }

        else -> {
            AuthDeviceScreenPortrait(
                authOptions = authOptions,
                onAdd = {
                    onAdd()
                },
                onSelect = { deviceId ->
                    onSelect(deviceId)
                },
                onBack = {
                    onBack()
                }
            )
        }
    }
}

@Composable
fun AuthDeviceScreenPortrait(
    authOptions: List<AuthOption>,
    onAdd: () -> Unit,
    onSelect: (deviceId: String) -> Unit,
    onBack: () -> Unit
) {
    Scaffold(
        topBar = { AuthDevicesScreenTopbar(onClick = { onBack() }) },
        bottomBar = {
            BottomAppBar(
                containerColor = MaterialTheme.colorScheme.background
            ) {
                DeviceBottomBar()
            }
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier.fillMaxWidth()
                .padding(horizontal = 15.dp)
                .padding(paddingValues = paddingValues)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth()
                        .height(75.dp)
                        .clip(MaterialTheme.shapes.medium)
                        .clickable {
                            onAdd()
                        },
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = Color.White
                    ),
                    shape = MaterialTheme.shapes.medium
                ) {
                    Row(
                        modifier = Modifier.fillMaxSize()
                            .padding(start = 15.dp, end = 15.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Create new terminal",
                            style = MaterialTheme.typography.titleSmall,
                            textAlign = TextAlign.Center
                        )
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = null,
                            modifier = Modifier.size(30.dp),
                            tint = Color.White
                        )
                    }
                }
            }
            items(count = authOptions.size) { index ->
                val shape =
                    if (index == authOptions.size - 1)
                        MaterialTheme.shapes.large
                    else
                        MaterialTheme.shapes.small
                OptionList(
                    authOption = authOptions.get(index),
                    shape = shape,
                    onClick = {
                        onSelect(authOptions.get(index).id)
                    }
                )
            }
        }
    }
}

@Composable
fun AuthDevicesScreenTopbar(onClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth()
            .padding(horizontal = 15.dp)
            .padding(top = 35.dp, bottom = 10.dp),
    ) {
        Card(
            shape = MaterialTheme.shapes.extraLarge,
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer
            ),
            modifier = Modifier.clip(MaterialTheme.shapes.extraLarge)
                .clickable {
                    onClick()
                }
        ) {
            Icon(
                imageVector = Icons.Default.KeyboardArrowLeft,
                contentDescription = null,
                modifier = Modifier.size(55.dp, 55.dp)
                    .padding(10.dp),
                tint = MaterialTheme.colorScheme.onPrimary
            )
        }
        Spacer(modifier = Modifier.width(20.dp))
        Row(
        ) {
            Text(
                text = "Select device",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
    }
}

@Composable
fun AuthDeviceScreenLandscape(
    authOptions: List<AuthOption>,
    onAdd: () -> Unit,
    onSelect: (deviceId: String) -> Unit,
    onBack: () -> Unit
) {
    Scaffold(
        topBar = { AuthDeviceScreenTopbarLandscape(onClick = { onBack() }) },
        bottomBar = {
            BottomAppBar(
                containerColor = MaterialTheme.colorScheme.background
            ) {
                DeviceBottomBar()
            }
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier.fillMaxWidth()
                .padding(horizontal = 15.dp)
                .padding(paddingValues = paddingValues)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth()
                        .height(80.dp)
                        .clip(MaterialTheme.shapes.medium)
                        .clickable {
                            onAdd()
                        },
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = Color.White
                    ),
                    shape = MaterialTheme.shapes.medium
                ) {
                    Row(
                        modifier = Modifier.fillMaxSize()
                            .padding(start = 15.dp, end = 15.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Create new terminal",
                            style = MaterialTheme.typography.titleSmall,
                            textAlign = TextAlign.Center
                        )
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = null,
                            modifier = Modifier.size(30.dp),
                            tint = Color.White
                        )
                    }
                }
            }
            items(count = authOptions.size) { index ->
                val shape =
                    if (index == authOptions.size - 1)
                        MaterialTheme.shapes.large
                    else
                        MaterialTheme.shapes.small
                OptionList(
                    authOption = authOptions.get(index),
                    shape = shape,
                    onClick = {
                        onSelect(authOptions.get(index).id)
                    }
                )
            }
        }
    }
}

@Composable
fun AuthDeviceScreenTopbarLandscape(onClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth()
            .padding(horizontal = 15.dp)
            .padding(top = 20.dp, bottom = 10.dp),
    ) {
        Card(
            shape = MaterialTheme.shapes.extraLarge,
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer
            ),
            modifier = Modifier.clip(MaterialTheme.shapes.extraLarge)
                .clickable { onClick() }
        ) {
            Icon(
                imageVector = Icons.Default.KeyboardArrowLeft,
                contentDescription = null,
                modifier = Modifier.size(50.dp, 50.dp)
                    .padding(10.dp),
                tint = MaterialTheme.colorScheme.onPrimary
            )
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Select device",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.padding(top = 2.dp)
            )
        }
    }
}

@Composable
fun DeviceBottomBar() {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.Bottom
    ) {
        Logo()
    }
}