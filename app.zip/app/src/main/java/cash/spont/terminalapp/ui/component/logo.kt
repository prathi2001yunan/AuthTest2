package cash.spont.terminalapp.ui.component

import androidx.compose.foundation.Image
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import cash.spont.terminalapp.R

object Logo

@Composable
fun Logo() {
    Image(
        painter = painterResource(id = if (isSystemInDarkTheme()) R.drawable.logo_dark else R.drawable.logo_light),
        contentDescription = "logo",
        modifier = Modifier.height(50.dp)
            .width(100.dp)
    )
}
