package cash.spont.terminalapp.ui

sealed class NavRoute(val route: String) {

    object Auth : NavRoute("Auth") {
        object Start : NavRoute("Auth.Start")
        object Login : NavRoute("Auth.Login")
        object Company : NavRoute("Auth.Company")
        object Device : NavRoute("Auth.Device")
        object NewDevice: NavRoute("Auth.NewDevice")
        object Loading: NavRoute("Auth.Loading")
    }

    object Order : NavRoute("Order") {
        object Wait : NavRoute("Order.Wait")
        object Detail : NavRoute("Order.Detail")
        object Tip : NavRoute("Order.Tip")
        object ThankYou : NavRoute("Order.ThankYou")
    }
}
