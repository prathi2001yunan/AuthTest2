package cash.spont.terminalapp

object AppConfig {
    var auth0ClientId = "22mP23yz8JLsHxy1Vzaq3vT8Dxzkijkc"
    var auth0Secret = "lvlXMdOzw9TkjJtfcgtjirnpuWDDTMWHidC0nFiQgGhHByLkQ-oXcNGQX9Tc_L3p"
    var auth0Domain = "https://spont-staging.eu.auth0.com"
    var auth0Audience = "https://auth0-jwt-authorizer"
    var dittoAppId = "fe60a4fb-95b3-488e-9a98-5e58d2b7b6e2"
    var dittoProvider = "auth0-auth"
}