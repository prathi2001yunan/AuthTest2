package cash.spont.terminalapp.ui.common

import java.text.NumberFormat
import java.util.Locale

val moneyFormat = NumberFormat.getCurrencyInstance(Locale.ITALY)
fun formatPrice(amount: Double): String {
    val amountValue = moneyFormat.format(amount).toString()
    return moneyFormat.currency?.symbol + amountValue.subSequence(0, amountValue.length - 1)
}