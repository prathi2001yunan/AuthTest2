package cash.spont.terminalapp.ui.component

import android.content.res.Configuration
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuItemColors
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import cash.spont.terminalapp.R
import kotlinx.coroutines.delay

@Composable
fun OrderWaitScreen(onDetails: () -> Unit) {
    val configuration = LocalConfiguration.current
    when (configuration.orientation) {
        Configuration.ORIENTATION_LANDSCAPE -> {
            LaunchedEffect(key1 = true) {
                delay(5000)
                onDetails()
            }
            OrderWaitScreenLandScape(R.drawable.wait_dark)
//            OrderWaitScreenLandScape(0)
        }

        else -> {
            LaunchedEffect(key1 = true) {
                delay(5000)
                onDetails()
            }
            OrderWaitScreenPortrait(R.drawable.wait_dark)
//            OrderWaitScreenPortrait(0)
        }
    }
}

@Composable
fun OrderWaitScreenPortrait(logoImage: Int) {
    if (logoImage == 0) {
        LogoSpontCenter()
    } else {
        Scaffold(
            topBar = {
                Logout()
            },
            bottomBar = {
                LogoSpontPortrait()
            }
        ) { paddingValues ->
            Column(
                modifier = Modifier.padding(paddingValues = paddingValues)
            )
            {
                LogoPortrait(logoImage = logoImage)
            }
        }
    }
}

@Composable
fun LogoPortrait(logoImage: Int) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .fillMaxHeight(0.95f),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Image(
            painter = painterResource(id = logoImage),
            contentDescription = null,
            modifier = Modifier
                .size(200.dp)
                .clip(CircleShape),
            contentScale = ContentScale.Crop,
        )
    }
}

@Composable
fun LogoSpontPortrait() {
    Column(
        modifier = Modifier.fillMaxWidth()
            .padding(bottom = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Bottom,
    ) {
        Logo()
    }
}

@Composable
fun LogoSpontCenter() {
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Logo()
    }
}

@Composable
fun OrderWaitScreenLandScape(logoImage: Int) {
    if (logoImage == 0) {
        LogoSpontCenter()
    } else {
        LogoSpontLandScape()
        Spacer(modifier = Modifier.height(20.dp))
        LogoLandScape(logoImage = logoImage)
    }
}

@Composable
fun LogoLandScape(logoImage: Int) {
    Column(
        modifier = Modifier.fillMaxWidth()
            .fillMaxHeight()
            .padding(top = 60.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Image(
            painter = painterResource(id = R.drawable.wait_dark),
            contentDescription = null,
            modifier = Modifier
                .size(180.dp)
                .clip(CircleShape),
            contentScale = ContentScale.Crop,
        )
    }
}

@Composable
fun LogoSpontLandScape() {
    Row(
        modifier = Modifier.fillMaxWidth()
            .fillMaxHeight()
            .padding(top = 30.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.Top,
    ) {
      Logo()
    }
    Logout()
}

@Composable
fun Logout() {
    var expanded by remember { mutableStateOf(false) }
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.End
    ) {
        Box {
            IconButton(onClick = { expanded = true }) {
                Icon(
                    imageVector = Icons.Default.MoreVert,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.background
                )
            }
            DropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false },
                modifier = Modifier.background(MaterialTheme.colorScheme.primaryContainer)
            )
            {
                DropdownMenuItem(
                    text = {
                        Text(
                            text = "Logout",
                            color = MaterialTheme.colorScheme.onPrimary
                        )
                    },
                    onClick = { expanded = false },
                )
            }
        }
    }
}

