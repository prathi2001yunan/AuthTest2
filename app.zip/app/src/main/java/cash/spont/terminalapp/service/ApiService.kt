package cash.spont.terminalapp.service

import android.app.Service
import android.content.Intent
import android.os.IBinder
import cash.spont.terminalapp.AppConfig
import cash.spont.terminalapp.SharedPreference
import cash.spont.terminalapp.model.AuthCodeInfo
import cash.spont.terminalapp.model.AuthTokenInfo
import io.ktor.client.HttpClient
import io.ktor.client.engine.android.Android
import io.ktor.client.features.RedirectResponseException
import io.ktor.client.features.ServerResponseException
import io.ktor.client.features.json.JsonFeature
import io.ktor.client.features.json.serializer.KotlinxSerializer
import io.ktor.client.features.logging.LogLevel
import io.ktor.client.features.logging.Logging
import io.ktor.client.request.forms.FormDataContent
import io.ktor.client.request.post
import io.ktor.client.request.url
import io.ktor.http.Parameters

class ApiService(private var config: AppConfig) : Service() {
    private var client: HttpClient = HttpClient(Android) {
        install(Logging) {
            level = LogLevel.ALL
        }
        install(JsonFeature) {
            serializer = KotlinxSerializer()
        }
    }
    private var accessToken = ""
    private var refreshToken = ""
    private var expiresIn = 0


    fun hasStoredToken(): Boolean {
        if (SharedPreference.getRefreshToken().isNullOrEmpty()) {
            this.refreshToken = SharedPreference.getRefreshToken().toString()
            return true
        }
        return false
    }

    suspend fun getDeviceCode(): AuthResponse<AuthCodeInfo> {
        try {
            val response = client.post<AuthCodeInfo> {
                url("${config.auth0Domain}/oauth/device/code")
                body = FormDataContent(Parameters.build {
                    append("client_id", config.auth0ClientId)
                    append("audience", config.auth0Audience)
                    append("scope", "profile email offline_access")
                })
            }
            val responseData: AuthCodeInfo = response
            print(responseData)
            return AuthResponse.Success(responseData)
        } catch (e: RedirectResponseException) {
            return AuthResponse.Error(e.response.status.description)
        } catch (e: ServerResponseException) {
            return AuthResponse.Error(e.response.status.description)
        } catch (e: Exception) {
            return AuthResponse.Error(e.message)
        }
    }

    suspend fun getDeviceToken(code: String): AuthResponse<AuthTokenInfo> {
        try {
            val response = client.post<AuthTokenInfo> {
                url("${config.auth0Domain}/oauth/token")
                body = FormDataContent(Parameters.build {
                    append("client_id", config.auth0ClientId)
                    append(
                        "grant_type", "urn:ietf:params:oauth:grant-type:device_code"
                    )
                    append("device_code", code)
                })
            }
            val responseToken: AuthTokenInfo = response
            print(responseToken)
            accessToken = responseToken.accessToken
            refreshToken = responseToken.refreshToken
            expiresIn = responseToken.expiresIn
            return AuthResponse.Success(responseToken)
        } catch (e: RedirectResponseException) {
            return AuthResponse.Error(e.response.status.description)
        } catch (e: ServerResponseException) {
            return AuthResponse.Error(e.response.status.description)
        } catch (e: Exception) {
            return AuthResponse.Error(e.message)
        }
    }

    suspend fun updateNewToken(): Boolean {
        try {
            val response = client.post<AuthTokenInfo> {
                url("${config.auth0Domain}/oauth/token")
                body = FormDataContent(Parameters.build {
                    append("client_id", config.auth0ClientId)
                    append("grant_type", "refresh_token")
                    append(
                        "client_secret", config.auth0Secret
                    )
                    append("refresh_token", refreshToken)
                })
            }
            return true
        } catch (e: Exception) {
            return false
        }
    }

    override fun onBind(p0: Intent?): IBinder? {
        return null
    }

    fun startTimer() {}

    fun stopTimer() {}
}

sealed class AuthResponse<T>(
    var data: T? = null, val message: String? = null
) {
    class Success<T>(data: T) : AuthResponse<T>(data)

    class Error<T>(message: String?, data: T? = null) : AuthResponse<T>(data, message)
}