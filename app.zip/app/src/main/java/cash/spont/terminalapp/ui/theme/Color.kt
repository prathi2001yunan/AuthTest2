package cash.spont.terminalapp.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFF4353ff)
val grey80 = Color(0xFF181818)
val white80 = Color(0xFFFFFFFF)
val black80 = Color(0xFF000000)
val grey90 = Color(0xff999999)
val grey70 = Color(0x1BA09C9C)
val grey60 = Color(0x57D8D8E0)

val Purple40 = Color(0xFF4353ff)
val grey40 = Color(0xFFC4C5CA)
val black40 = Color(0xFF000000)
val white40 = Color(0xFFFFFFFF)
val grey30 = Color(0xFF414141)
val grey20 = Color(0x8F0C0101)
val grey10 = Color(0x573B3B3D)