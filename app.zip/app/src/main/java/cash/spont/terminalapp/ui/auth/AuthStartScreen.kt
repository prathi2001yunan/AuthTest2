package cash.spont.terminalapp.ui.component

import android.annotation.SuppressLint
import android.content.res.Configuration
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import cash.spont.terminalapp.R

@Composable
fun AuthStartScreen(onLogin: () -> Unit) {
    val configuration = LocalConfiguration.current
    when (configuration.orientation) {
        Configuration.ORIENTATION_LANDSCAPE -> {
            AuthStartScreenLandScape(onTap = { onLogin() })
        }

        else -> {
            AuthStartScreenPortrait(onTap = { onLogin() })
        }
    }
}

@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@Composable
fun AuthStartScreenPortrait(onTap: () -> Unit) {
    Scaffold(
        topBar = {
            StartScreenLogo()
        },
        bottomBar = {
            Column(
                modifier = Modifier.fillMaxWidth()
                    .padding(horizontal = 25.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                StartScreenDescription(description = "De beste tool voor je horeca onderneming.")
                Spacer(modifier = Modifier.height(25.dp))
                Button(onClick = {onTap()})
                Spacer(modifier = Modifier.height(15.dp))
            }
        },
    ) { paddingValues ->
        Column(
            modifier = Modifier.fillMaxWidth()
                .padding(paddingValues = paddingValues),
        ) {
            StartScreenImage()
        }
    }
}

@Composable
fun StartScreenLogo() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 30.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Logo()
    }
}

@Composable
fun StartScreenImage() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .fillMaxHeight(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.terminal_dark),
            contentDescription = null,
            modifier = Modifier.size(390.dp),
        )
    }
}

@Composable
fun StartScreenDescription(description: String) {
    Box(
        modifier = Modifier.size(250.dp, 80.dp),
    ) {
        Text(
            description,
            color = MaterialTheme.colorScheme.onPrimary,
            style = MaterialTheme.typography.titleMedium,
            textAlign = TextAlign.Center,
        )
    }
}

@Composable
fun Button(onClick: () -> Unit) {
    androidx.compose.material3.Button(
        onClick = { onClick() },
        shape = MaterialTheme.shapes.small,
        modifier = Modifier.fillMaxWidth()
            .height(55.dp),
        colors = ButtonDefaults.buttonColors(MaterialTheme.colorScheme.primary),
    ) {
        Text(
            "Connect to your Spont",
            style = MaterialTheme.typography.labelSmall,
            color = Color.White,
        )
    }
}

@Composable
fun AuthStartScreenLandScape(onTap: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
    ) {
        StartSpontLogo()
        Spacer(modifier = Modifier.height(30.dp))
        Row() {
            StartScreenLogoLandscape()
            Spacer(modifier = Modifier.width(80.dp))
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Spacer(modifier = Modifier.height(20.dp))
                StartScreenDescription(description = "De beste tool voor je horeca onderneming.")
                Spacer(modifier = Modifier.height(80.dp))
                ButtonLandscape(onClick = {onTap()})
            }
        }
    }
}

@Composable
fun StartSpontLogo() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 10.dp),
        horizontalArrangement = Arrangement.Center,
    ) {
        Logo()
    }
}

@Composable
fun StartScreenLogoLandscape() {
    Column(
        modifier = Modifier.padding(start = 95.dp)
            .padding(bottom = 10.dp),
    ) {
        Image(
            painter = painterResource(id = R.drawable.terminal_dark),
            contentDescription = null,
        )
    }
}

@Composable
fun ButtonLandscape(onClick: () -> Unit) {
    androidx.compose.material3.Button(
        onClick = { onClick() },
        modifier = Modifier.fillMaxWidth()
            .padding(horizontal = 30.dp)
            .background(MaterialTheme.colorScheme.primary, MaterialTheme.shapes.small)
            .clip(MaterialTheme.shapes.extraLarge)
            .height(60.dp),
        colors = ButtonDefaults.buttonColors(MaterialTheme.colorScheme.primary),
    ) {
        Text(
            "Connect to your Spont",
            style = MaterialTheme.typography.labelSmall,
            color = Color.White,
        )
    }
}
